TOPIC:

Python Currency Convertor

Libraries Used:

Tkinter and forex-python

pip install forex-python


Working:-

This currency convertor has a simple GUI design. It contains Two Lists of currencies. First list is the Currency From list
and the second list is Currency To list. It contains an Input Field where the user can input the amount. After all the
required inputs, the output is displayed in another Output Amount Field.

(Requirements):

Working Internet connection with down speed of atleast 1Mbps