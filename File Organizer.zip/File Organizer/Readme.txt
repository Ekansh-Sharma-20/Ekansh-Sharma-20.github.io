TOPIC:

File Organizer

Libraries Used:

Os and shutil

Working:-

This is a simple program which segregates the files into different folders depending on their format. Firstly the program makes
Multiple folders like Video, Pictures, Documents etc. and then moves the files into these folders based on their extension, for example all
the files having the extension as .jpg or .png or .gif are moved to the folder named images.

Benefits :-

Some people have a habit to save every new thing they find on the internet on the desktop and then they are not able to find a particular file
in that gigantic mess of their desktop, so just by running this program, it de-clutters their desktop or any particular folder and sorts file in order
so that it is easy to find stuff and also to save hours of hassle of looking around.
