TOPIC:

Instagram DP Downloader

Libraries Used:

Instaloader

pip install instaloader


Working:-

This is a very simple program to download the profile picture of a particular user on instagram. Using the instaloder library you can
directly enter the username of a user with the @ symbol and the file automatically creates a folder containing the DP of the user.


(Requirements):

Working Internet connection with down speed of atleast 1Mbps