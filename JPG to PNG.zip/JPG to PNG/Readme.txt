TOPIC:

JPG TO PNG CONVERTOR

Libraries Used:

Using sys, os and PIL(Image Filter)
PIL PACKAGE- pip install pillow

Working:-

JPG to PNG is a type of file conversion tool in which we convert a type of file into another type of file. 
and for this we import an image from our path where the file is stored and then we click on convert JPG-->PNG TOOL and 
allocate the path to store that file by taking a new name for that file(image). 

Benefits:-

A JPG image quality wil degrade slightly each time it is saved , while a PNG file is a 'lossless format' which means
the quality will not change over time  to time.