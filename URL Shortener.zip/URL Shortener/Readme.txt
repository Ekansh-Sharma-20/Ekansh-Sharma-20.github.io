TOPIC:

URL Shortener

Libraries Used:

pyshorteners

pip install pyshorteners


Working:-

Using the pyshorteners library we are easily able to convert the link in to a tiny url. Which can be used to share to an audience, this removes
the hassle of going to multiple malicious websites and searching for a good url converter.


Benefits :- 

This can be used by affiliate marketers to share affiliate links without making the link seem obvious to the user.

(Requirements):

Working Internet connection with down speed of atleast 1Mbps