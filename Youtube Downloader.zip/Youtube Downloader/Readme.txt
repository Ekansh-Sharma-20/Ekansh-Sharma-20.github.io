TOPIC:

Youtube Video Downloader

Libraries Used:

pytube

pip install pytube

Working:-

Using pytube we are able to run the url of the video through and download the video without any other files. The downloader downloads the video in the
best possible video quality.


Benefits :- 

This can be used to download videos from youtube, without requirement of any third party potential silent mining softwares.


(Requirements):

Working Internet connection with down speed of atleast 5Mbps